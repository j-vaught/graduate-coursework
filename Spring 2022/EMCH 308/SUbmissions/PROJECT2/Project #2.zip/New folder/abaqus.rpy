# -*- coding: mbcs -*-
#
# Abaqus/CAE Release 2020 replay file
# Internal Version: 2019_09_13-13.49.31 163176
# Run by bgehant on Mon Apr 25 22:50:05 2022
#

# from driverUtils import executeOnCaeGraphicsStartup
# executeOnCaeGraphicsStartup()
#: Executing "onCaeGraphicsStartup()" in the site directory ...
from abaqus import *
from abaqusConstants import *
session.Viewport(name='Viewport: 1', origin=(0.0, 0.0), width=351.333312988281, 
    height=215.422225952148)
session.viewports['Viewport: 1'].makeCurrent()
session.viewports['Viewport: 1'].maximize()
from caeModules import *
from driverUtils import executeOnCaeStartup
executeOnCaeStartup()
session.viewports['Viewport: 1'].partDisplay.geometryOptions.setValues(
    referenceRepresentation=ON)
openMdb(
    pathName='C:/Users/bgehant/Downloads/EMCH 308 Project 2 beam element (1).cae')
#: The model database "C:\Users\bgehant\Downloads\EMCH 308 Project 2 beam element (1).cae" has been opened.
session.viewports['Viewport: 1'].setValues(displayedObject=None)
p = mdb.models['2D Beam'].parts['Part-1']
session.viewports['Viewport: 1'].setValues(displayedObject=p)
a = mdb.models['2D Beam'].rootAssembly
session.viewports['Viewport: 1'].setValues(displayedObject=a)
session.viewports['Viewport: 1'].assemblyDisplay.setValues(
    optimizationTasks=OFF, geometricRestrictions=OFF, stopConditions=OFF)
mdb.jobs['2D-Job'].submit(consistencyChecking=OFF)
#: The job input file "2D-Job.inp" has been submitted for analysis.
mdb.jobs['Shell-Job'].submit(consistencyChecking=OFF)
#: The job input file "Shell-Job.inp" has been submitted for analysis.
mdb.jobs['Solid-Job'].submit(consistencyChecking=OFF)
#: The job input file "Solid-Job.inp" has been submitted for analysis.
#: Job 2D-Job: Analysis Input File Processor completed successfully.
#: Job 2D-Job: Abaqus/Standard completed successfully.
#: Job Shell-Job: Analysis Input File Processor completed successfully.
#: Job 2D-Job completed successfully. 
#: Job Solid-Job: Analysis Input File Processor completed successfully.
#: Job Shell-Job: Abaqus/Standard completed successfully.
#: Job Shell-Job completed successfully. 
#: Job Solid-Job: Abaqus/Standard completed successfully.
#: Job Solid-Job completed successfully. 
o3 = session.openOdb(name='C:/temp/2D-Job.odb')
#: Model: C:/temp/2D-Job.odb
#: Number of Assemblies:         1
#: Number of Assembly instances: 0
#: Number of Part instances:     1
#: Number of Meshes:             1
#: Number of Element Sets:       3
#: Number of Node Sets:          5
#: Number of Steps:              1
session.viewports['Viewport: 1'].setValues(displayedObject=o3)
session.viewports['Viewport: 1'].makeCurrent()
session.viewports['Viewport: 1'].odbDisplay.basicOptions.setValues(
    renderBeamProfiles=ON)
session.viewports['Viewport: 1'].view.setValues(nearPlane=6.33679, 
    farPlane=7.51961, width=4.52046, height=2.24474, cameraPosition=(0.129752, 
    5.42881, 4.30246), cameraUpVector=(0.0869416, 0.617486, -0.781762), 
    cameraTarget=(-8.93027e-09, -3.73641e-07, 6.57555e-07))
session.viewports['Viewport: 1'].view.setValues(nearPlane=6.0211, 
    farPlane=7.8353, width=4.29526, height=2.13291, cameraPosition=(-2.56323, 
    5.42881, 3.45801), cameraUpVector=(0.552504, 0.617486, -0.559866), 
    cameraTarget=(1.76416e-07, -3.73641e-07, 7.15675e-07))
session.viewports['Viewport: 1'].odbDisplay.display.setValues(plotState=(
    CONTOURS_ON_DEF, ))
a = mdb.models['2D Beam'].rootAssembly
session.viewports['Viewport: 1'].setValues(displayedObject=a)
o3 = session.openOdb(name='C:/temp/Shell-Job.odb')
#: Model: C:/temp/Shell-Job.odb
#: Number of Assemblies:         1
#: Number of Assembly instances: 0
#: Number of Part instances:     1
#: Number of Meshes:             1
#: Number of Element Sets:       5
#: Number of Node Sets:          5
#: Number of Steps:              1
session.viewports['Viewport: 1'].setValues(displayedObject=o3)
session.viewports['Viewport: 1'].makeCurrent()
a = mdb.models['2D Beam'].rootAssembly
session.viewports['Viewport: 1'].setValues(displayedObject=a)
session.viewports['Viewport: 1'].setValues(
    displayedObject=session.odbs['C:/temp/Shell-Job.odb'])
session.viewports['Viewport: 1'].view.setValues(nearPlane=3.53302, 
    farPlane=5.37877, width=2.56817, height=1.27528, viewOffsetX=0.161142, 
    viewOffsetY=0.0093126)
session.viewports['Viewport: 1'].odbDisplay.display.setValues(plotState=(
    CONTOURS_ON_DEF, ))
session.viewports['Viewport: 1'].odbDisplay.basicOptions.setValues(
    renderShellThickness=ON)
a = mdb.models['2D Beam'].rootAssembly
session.viewports['Viewport: 1'].setValues(displayedObject=a)
o3 = session.openOdb(name='C:/temp/Solid-Job.odb')
#: Model: C:/temp/Solid-Job.odb
#: Number of Assemblies:         1
#: Number of Assembly instances: 0
#: Number of Part instances:     1
#: Number of Meshes:             1
#: Number of Element Sets:       3
#: Number of Node Sets:          4
#: Number of Steps:              1
session.viewports['Viewport: 1'].setValues(displayedObject=o3)
session.viewports['Viewport: 1'].makeCurrent()
a = mdb.models['2D Beam'].rootAssembly
session.viewports['Viewport: 1'].setValues(displayedObject=a)
session.viewports['Viewport: 1'].setValues(
    displayedObject=session.odbs['C:/temp/Solid-Job.odb'])
session.viewports['Viewport: 1'].odbDisplay.display.setValues(plotState=(
    CONTOURS_ON_DEF, ))
