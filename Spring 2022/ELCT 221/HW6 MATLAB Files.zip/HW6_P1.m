clc;
clear;
format compact;

%Input Data
R=4;
XL=5;
Vamp=96;
Vphase=0;

%calculations
ZR=R;
ZL=j*XL;
ZT=ZR+ZL;

V=Vamp*exp(j*Vphase);% total voltage
I=V/ZT;%total current

%Thevenin Voltage
Va=V-I*R;
disp("Thevenin source amplitude: "+abs(Va)+" V");
disp("Thevenin source phase in rads: "+angle(Va));

%Thevenin Impedance
Thevenin=1/(1/ZR+1/ZL);
disp("Real part of Thevenin equivalent impedance: "+real(Thevenin)+" Ohm");
disp("Imaginary part of Thevenin equivalent impedance: "+imag(Thevenin)+" Ohm");