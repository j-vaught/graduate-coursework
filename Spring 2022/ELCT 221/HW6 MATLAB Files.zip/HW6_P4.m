clc;
clear;
format compact;

%Input Data
frequency=10e3; VSamp=20; VSPhase=0.25;
Rs=8; R1=8; R2=9; R3=4; L1=0.23e-3; L2=0.07e-3; C1=1.4e-6; 

%calculations
omega=2*pi*frequency;
ZR1=R1;
ZR2=R2;
ZR3=R3;
ZRs=Rs;
ZC1=-j/(omega*C1);
ZL1=j*omega*L1;
ZL2=j*omega*L2;
VS=VSamp*exp(j*VSPhase);%voltage

ImpedanceMatrix=[1/ZRs+1/(ZR1+ZL1)+1/(ZR2+ZL2),-1/(ZR2+ZL2);-1/(ZR2+ZL2),1/(ZR2+ZL2)+1/(ZR3+ZC1)];
CurrentMatrix=[VS/ZRs;0];
NodeVoltages=ImpedanceMatrix\CurrentMatrix;

%Thevenin Voltage
disp("Thevenin source amplitude: "+abs(NodeVoltages(2))+" V");
disp("Thevenin source phase in rads: "+angle(NodeVoltages(2))+" rad");

%Thevenin Impedance
TheveninImpedance=1/(1/(1/(1/ZRs+1/(ZR1+ZL1))+ZR2+ZL2)+1/(ZR3+ZC1));
disp("Real part of Thevenin equivalent impedance: "+real(TheveninImpedance)+" Ohm");
disp("Imaginary part of Thevenin equivalent impedance: "+imag(TheveninImpedance)+" Ohm");

EquivalentImpedance=conj(TheveninImpedance);
disp("Real part of matching load impedance: "+real(EquivalentImpedance)+" Ohm");
disp("Imaginary part of matching load impedance: "+imag(EquivalentImpedance)+" Ohm");

if(imag(EquivalentImpedance)>0)
    disp("Series connection of resistor and inductor.");
    EquivalentInductor=imag(EquivalentImpedance)/omega;
    disp("Equivalent Inductor: "+EquivalentInductor+" H");
elseif(imag(EquivalentImpedance)<0)
    disp("Series connection of resistor and capacitor.");
    EquivalentCapacitor=1/(-imag(EquivalentImpedance)*omega);
disp("Equivalent Capacitor: "+EquivalentCapacitor+" F");
end



