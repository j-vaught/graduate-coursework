clc;
clear;
format compact;

%Input Data
frequency=8e6; VSamp=40; VSPhase=0.25;
R1=32.5;L1=0.75e-6; C1=125e-12; C2=80e-12; 

%calculations
omega=2*pi*frequency;
ZR1=R1;
ZC1=-j/(omega*C1);
ZC2=-j/(omega*C2);
ZL1=j*omega*L1;

VS=VSamp*exp(j*VSPhase);%voltage

ImpedanceMatrix=[1/ZR1+1/ZC1+1/ZL1,-1/ZL1;-1/ZL1,1/ZC2+1/ZL1];
CurrentMatrix=[VS/ZR1;0];
NodeVoltages=ImpedanceMatrix\CurrentMatrix;

%Thevenin Voltage
disp("Thevenin source amplitude: "+abs(NodeVoltages(2))+" V");
disp("Thevenin source phase in rads: "+angle(NodeVoltages(2))+" rad");

%Thevenin Impedance
TheveninImpedance=1/(1/ZC2+1/(ZL1+1/(1/ZR1+1/ZC1)));
disp("Real part of Thevenin equivalent impedance: "+real(TheveninImpedance)+" Ohm");
disp("Imaginary part of Thevenin equivalent impedance: "+imag(TheveninImpedance)+" Ohm");

if(imag(TheveninImpedance)>0)
    disp("Series connection of resistor and inductor.");
elseif(imag(TheveninImpedance)<0)
    disp("Series connection of resistor and capacitor.");
end


EquivalentImpedance=conj(TheveninImpedance);
disp("Real part of matching load impedance: "+real(EquivalentImpedance)+" Ohm");
disp("Imaginary part of matching load impedance: "+imag(EquivalentImpedance)+" Ohm");

if(imag(EquivalentImpedance)>0)
    disp("Series connection of resistor and inductor.");
    EquivalentInductor=imag(EquivalentImpedance)/omega;
    disp("Equivalent Inductor: "+EquivalentInductor+" H");
elseif(imag(EquivalentImpedance)<0)
    disp("Series connection of resistor and capacitor.");
    EquivalentCapacitor=1/(-imag(EquivalentImpedance)*omega);
disp("Equivalent Capacitor: "+EquivalentCapacitor+" F");
end



