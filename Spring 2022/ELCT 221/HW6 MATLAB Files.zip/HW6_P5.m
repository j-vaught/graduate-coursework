clc;
clear;
format compact;

%Input Data
R1=130; R2=145; L1=24e-6; L2=21e-6; C1=10e-9; C2=12e-9; 
frequency=1e6; VSamp=12;VSPhase=0.1;

%calculations
omega=2*pi*frequency;
ZR1=R1;
ZR2=R2;
ZL1=j*omega*L1;
ZL2=j*omega*L2;
ZC1=-j/(omega*C1);
ZC2=-j/(omega*C2);

VS=VSamp*exp(j*VSPhase);%voltage

%Mesh Analysis
ZRLC1=ZR1+ZC1+ZL1;
ZRLC2=1/(1/ZR2+1/ZL2+1/ZC2);
ImpedanceMatrix=[ZRLC1,-ZRLC1;-ZRLC1,ZRLC2+ZRLC1];
VoltageMatrix=[VS;0];
MeshCurrents=ImpedanceMatrix\VoltageMatrix;

%Norton Current
disp("Norton source amplitude: "+abs(MeshCurrents(2))+" A");
disp("Norton source phase in rads: "+angle(MeshCurrents(2))+" rad");

%Norton Impedance
NortonImpedance=ZRLC2;
disp("Real part of Thevenin equivalent impedance: "+real(NortonImpedance)+" Ohm");
disp("Imaginary part of Thevenin equivalent impedance: "+imag(NortonImpedance)+" Ohm");

if(imag(NortonImpedance)>0)
    disp("Series connection of resistor and inductor.");
elseif(imag(NortonImpedance)<0)
    disp("Series connection of resistor and capacitor.");
end



