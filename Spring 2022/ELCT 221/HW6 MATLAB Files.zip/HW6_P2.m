clc;
clear;
format compact;

%Input Data
VSamp=36; VSPhase=1; ISamp=8e-3; ISPhase=0.5;
frequency=24e6; R1=10e3; L1=80e-6; C1=1.4e-12;

%calculations
omega=2*pi*frequency;
ZR1=R1;
ZC1=-j/(omega*C1);
ZL1=j*omega*L1;

VS=VSamp*exp(j*VSPhase);%voltage
IS=ISamp*exp(j*ISPhase);%current

ImpedanceMatrix=[1/ZR1+1/ZL1+1/ZC1,-1/ZC1;-1/ZC1,1/ZC1];
CurrentMatrix=[VS/ZR1;IS];
NodeVoltages=ImpedanceMatrix\CurrentMatrix;

%Thevenin Voltage
disp("Thevenin source amplitude: "+abs(NodeVoltages(2))+" V");
disp("Thevenin source phase in rads: "+angle(NodeVoltages(2))+" rad");

%Thevenin Impedance
TheveninImpedance=ZC1+1/(1/ZR1+1/ZL1);
disp("Real part of Thevenin equivalent impedance: "+real(TheveninImpedance)+" Ohm");
disp("Imaginary part of Thevenin equivalent impedance: "+imag(TheveninImpedance)+" Ohm");

if(imag(TheveninImpedance)>0)
    disp("Series connection of resistor and inductor.");
elseif(imag(TheveninImpedance)<0)
    disp("Series connection of resistor and capacitor.");
end
