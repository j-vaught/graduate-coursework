%%Close figures and clear command window
close all;
clear;
clc;

%%Enter experimentally determined motor parameters
L = 0.5; 
R = 51;
K = 0.0744;
J = 0.01;
B = 1.382e-4;