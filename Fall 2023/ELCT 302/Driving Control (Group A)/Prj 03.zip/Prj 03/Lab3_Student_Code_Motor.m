%% Notation
%ELCT 302
%Team Number:Group Letter
%Group Member Name, Group Member Name
%Lab 3

%% Close open windows and clear command window
close all;
clear all;
clc;

%% Measured motor parameters
ti = 1E3;

L = 318E-9;                               %insert value here
R = 2.93;                                 %insert value here
K = 0.0086;                               %insert value here
J = 1.3517E-11;                           %insert value here
B = 1.7149E-5;                            %insert value here

%% Transfer function of the open loop DC Motor
num = K;                                  %insert value here
denom = [J*L (J*R)+(B*L) (R*B)+K^2];      %insert value here
Gmotor = tf(num,denom);                   %open loop transfer function

%% Gains of the forward loop
RH = 1/(2*pi); %insert value here         %Rad to Hz
GR = 7.5;      %insert value here         %Gear Ratio 
FV = 3.3;      %insert value here         %Frequency to voltage
ADC = 1;       %insert value here         %ADC conversion voltage to ADC#
DutyC = 1;     %insert value here         %Conversion from ADC# to Duty cycle
Vbat = 7.2;    %insert value here         %Gain of the battery
Feedback = RH*FV*ADC;                     %Feedback path gain
Gforward = GR*Gmotor*DutyC*Feedback*Vbat; %Forward path gain

Openlooptf = tf(Gforward,(1+(Gforward*Feedback))); %Nick made

%% Bode plot of the open-loop transfer function including forward gain
figure;
bode(Openlooptf); %insert transfer function
title('Open Loop Bode Plot');
grid on;

%% Declaring wc and wm
wc = ; %insert crossover frequency (rad/s)
wm = ; %insert phase margin

%% Frequency response
F = freqresp();    %insert [transfer function, wc]
magGforward = abs(F)                %magnitude for PI controller
angleGforward = angle(F)            %phase for PI controller

%% Calulcating parameters for the PI controller
Kp =
Ki =

%% Including the PI controller in the control loop
num1 = []; %insert Kp and Ki in transfer function form
denom1 = []; %insert Kp and Ki in transfer function form
Gc = tf(num1,denom1);                 %transfer function for PI controller
Gcopen = Gc*Gforward;                 %open-loop + controller transfer function

%% Margin plot with the PI controller but not the feedback loop
figure;
margin(Gcopen);
title('Forward Loop Bode Plot with Controller but no Feedback');
grid on;

%% Nyquist plot with the PI controller but not the feedback loop
figure;
nyquist(); %insert transfer function
title('Forward Loop Nyquist Plot with Controller but no Feedback');
grid on;

%% The complete transfer function
Gclose=Gcopen/(1+(Gcopen));         %closed loop system transfer function

%% Step response of the closed loop
figure;
%step(); % plot the step response of Gclose
title('Closed Loop Step Response');
grid on;